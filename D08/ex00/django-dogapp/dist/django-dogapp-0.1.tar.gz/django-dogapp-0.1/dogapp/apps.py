from django.apps import AppConfig


class DogappConfig(AppConfig):
    name = 'dogapp'
